package day16.trolley;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu m = new Menu();
		m.go();
	}

}
